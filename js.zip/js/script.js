var map = L.map('map').setView([0, 0], 2);
var santaInitialPosition = [66.5, 25]; // Posizione iniziale di Babbo Natale

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 18,
}).addTo(map);

var santaIcon = L.icon({
  iconUrl: 'img/santa.png',
  iconSize: [100, 100],
});

var santaMarker = L.marker(santaInitialPosition, { icon: santaIcon }).addTo(map);
var santaPath = [];
santaPath.push(santaInitialPosition);
var santaPathLine = L.polyline(santaPath, { color: 'green' }).addTo(map);

var capitalCities = {
  // Europe
  "Albania": [41.3275, 19.8187],
  "Andorra": [42.5063, 1.5218],
  "Austria": [48.2082, 16.3738],
  "Belarus": [53.9045, 27.5615],
  "Belgium": [50.8503, 4.3517],
  "Bosnia and Herzegovina": [43.8563, 18.4131],
  "Bulgaria": [42.6977, 23.3219],
  "Croatia": [45.8150, 15.9819],
  "Cyprus": [35.1856, 33.3823],
  "Czech Republic": [50.0755, 14.4378],
  "Denmark": [55.6761, 12.5683],
  "Estonia": [59.4370, 24.7536],
  "Finland": [60.1695, 24.9354],
  "France": [48.8566, 2.3522],
  "Germany": [52.5200, 13.4050],
  "Greece": [37.9838, 23.7275],
  "Hungary": [47.4979, 19.0402],
  "Iceland": [64.1466, -21.9426],
  "Ireland": [53.3498, -6.2603],
  "Italy": [41.9028, 12.4964],
  "Kosovo": [42.6026, 20.9030],
  "Latvia": [56.9496, 24.1052],
  "Liechtenstein": [47.1410, 9.5209],
  "Lithuania": [54.6872, 25.2797],
  "Luxembourg": [49.6116, 6.1319],
  "Malta": [35.8989, 14.5146],
  "Moldova": [47.0105, 28.8638],
  "Monaco": [43.7384, 7.4246],
  "Montenegro": [42.4304, 19.2594],
  "Netherlands": [52.3676, 4.9041],
  "North Macedonia": [41.9973, 21.4280],
  "Norway": [59.9139, 10.7522],
  "Poland": [52.2297, 21.0122],
  "Portugal": [38.7223, -9.1393],
  "Romania": [44.4268, 26.1025],
  "Russia": [55.7558, 37.6176],
  "San Marino": [43.9424, 12.4578],
  "Serbia": [44.7866, 20.4489],
  "Slovakia": [48.1486, 17.1077],
  "Slovenia": [46.0569, 14.5058],
  "Spain": [40.4168, -3.7038],
  "Sweden": [59.3293, 18.0686],
  "Switzerland": [46.9480, 7.4481],
  "Ukraine": [50.4501, 30.5234],
  "United Kingdom": [51.5074, -0.1278],
  "Vatican City": [41.9029, 12.4534],
  "Åland Islands": [60.1785, 19.9156],
  "Faroe Islands": [62.0079, -6.7716],
  "Gibraltar": [36.1408, -5.3536],
  "Guernsey": [49.4657, -2.5853],
  "Isle of Man": [54.2361, -4.5481],
  "Jersey": [49.2144, -2.1313],
  "Svalbard and Jan Mayen": [78.9684, 11.8746],

  // Africa
  "Egitto": [30.0330, 31.2336],
  "Nigeria": [9.0820, 8.6753],
  "Sudafrica": [-25.7460, 28.1871],
  "Algeria": [28.0339, 1.6596],
  "Etiopia": [9.1450, 40.4897],
  "Angola": [-8.8383, 13.2344],
  "Marocco": [31.7917, -7.0926],
  "Kenya": [-1.2921, 36.8219],
  "Sudan": [15.5007, 32.5599],
  "Ghana": [7.9465, -1.0232],
  "Madagascar": [-18.8792, 47.5079],
  "Camerun": [3.8480, 11.5021],
  "Costa d'Avorio": [7.5400, -5.5471],
  "Niger": [17.6078, 8.0817],
  "Burkina Faso": [12.2383, -1.5616],
  "Mali": [17.5707, -3.9962],
  "Malawi": [-13.2543, 34.3015],
  "Zambia": [-13.1339, 27.8493],
  "Senegal": [14.7167, -17.4677],
  "Chad": [15.4542, 18.7322],
  "Zimbabwe": [-19.0154, 29.1549],
  "Ruanda": [-1.9403, 29.8739],
  "Tunisia": [33.8869, 9.5375],
  "Guinea": [9.9456, -9.6966],
  "Benin": [9.3077, 2.3158],
  "Burundi": [-3.3731, 29.9189],
  "Togo": [8.6195, 0.8248],
  "Sierra Leone": [8.4606, -11.7799],
  "Libia": [26.3351, 17.2283],
  "Congo": [-4.0383, 21.7587],
  "Liberia": [6.4281, -9.4295],
  "Mauritania": [21.0079, -10.9408],
  "Eswatini": [-26.5225, 31.4659],
  "Lesotho": [-29.6095, 28.2336],
  "Namibia": [-22.9576, 18.4904],
  "Botswana": [-22.3285, 24.6849],
  "Gabon": [-0.8037, 11.6094],
  "Gambia": [13.4432, -15.3101],
  "Guinea-Bissau": [11.8037, -15.1804],
  "Mauritius": [-20.3484, 57.5522],
  "Seychelles": [-4.6796, 55.492],
  "Comore": [-11.6455, 43.3333],
  "Cabo Verde": [14.9215, -23.5087],
  "São Tomé and Príncipe": [0.1864, 6.6131],
  "Mauritius": [-20.3484, 57.5522],
  "Djibouti": [11.5806, 43.1425],
  "Réunion": [-21.1151, 55.5364],
  "Mayotte": [-12.8275, 45.1662],
  "Western Sahara": [24.2155, -12.8858],
  "South Sudan": [7.8627, 30.2176],
  "Somalia": [2.0469, 45.3182],
  "Eritrea": [15.1794, 39.7823],
  "Equatorial Guinea": [3.7523, 8.7829],
  "Central African Republic": [6.6111, 20.9394],

  // Asia
  "Afghanistan": [34.5553, 69.2075],
  "Armenia": [40.1792, 44.4991],
  "Azerbaijan": [40.4093, 49.8671],
  "Bahrain": [26.0667, 50.5577],
  "Bangladesh": [23.8103, 90.4125],
  "Bhutan": [27.5142, 90.4336],
  "Brunei": [4.5353, 114.7277],
  "Cambodia": [11.5564, 104.9282],
  "Cyprus": [35.1264, 33.4299],
  "Georgia": [41.7151, 44.8271],
  "Indonesia": [-0.7893, 113.9213],
  "Iran": [32.4279, 53.6880],
  "Israel": [31.7683, 35.2137],
  "Jordan": [31.9522, 35.2332],
  "Kazakhstan": [48.0196, 66.9237],
  "Kuwait": [29.3759, 47.9774],
  "Kyrgyzstan": [41.2044, 74.7661],
  "Laos": [19.8563, 102.4955],
  "Lebanon": [33.8547, 35.8623],
  "Maldives": [4.1755, 73.5093],
  "Malaysia": [3.139, 101.6869],
  "Mongolia": [47.9212, 106.9186],
  "Myanmar (Birmania)": [19.745, 96.1296],
  "Nepal": [27.7172, 85.324],
  "North Korea (Corea del Nord)": [39.0392, 125.7625],
  "Oman": [23.614, 58.5903],
  "Pakistan": [30.3753, 69.3451],
  "Palestine": [31.9465, 35.2731],
  "Philippines": [14.6091, 121.0223],
  "Qatar": [25.276987, 51.518919],
  "Saudi Arabia (Arabia Saudita)": [24.7136, 46.6753],
  "Singapore": [1.3521, 103.8198],
  "South Korea (Corea del Sud)": [37.5665, 126.978],
  "Sri Lanka": [6.9271, 79.8612],
  "Syria": [33.5138, 36.2765],
  "Taiwan": [25.0328, 121.5654],
  "Tajikistan": [38.861, 71.2761],
  "Thailand": [13.7563, 100.5018],
  "Turkmenistan": [37.9601, 58.3261],
  "United Arab Emirates (Emirati Arabi Uniti)": [24.4539, 54.3773],
  "Uzbekistan": [41.3775, 64.5853],
  "Vietnam": [21.0278, 105.8342],
  "Yemen": [15.3694, 44.191],
  "India": [20.5937, 78.9629],

  // America

  "Washington, D.C. (Stati Uniti)": [38.8951, -77.0364],
  "Ottawa (Canada)": [45.4215, -75.6972],
  "Brasilia (Brasile)": [-15.8267, -47.9218],
  "Città del Messico (Messico)": [19.4326, -99.1332],
  "Buenos Aires (Argentina)": [-34.6037, -58.3816],
  "Lima (Perù)": [-12.0464, -77.0428],
  "Bogotà (Colombia)": [4.7110, -74.0721],
  "Caracas (Venezuela)": [10.4806, -66.9036],
  "Santiago (Cile)": [-33.4489, -70.6693],
  "Quito (Ecuador)": [-0.1807, -78.4678],
  "La Paz (Bolivia)": [-16.5075, -68.1302],
  "Havana (Cuba)": [23.1136, -82.3666],
  "Città del Guatemala (Guatemala)": [14.6349, -90.5069],
  "Tegucigalpa (Honduras)": [14.0723, -87.1921],
  "Asunción (Paraguay)": [-25.2637, -57.5759],
  "Managua (Nicaragua)": [12.8654, -85.2072],
  "San José (Costa Rica)": [9.9281, -84.0907],
  "Panamá (Panamá)": [8.9824, -79.5199],
  "Montevideo (Uruguay)": [-34.9011, -56.1645],
  "Port of Spain (Trinidad e Tobago)": [10.6606, -61.5151],
  "Georgetown (Guyana)": [6.8013, -58.1551],
  "Paramaribo (Suriname)": [5.8520, -55.2038],
  "Nassau (Bahamas)": [25.0343, -77.3963],
  "Belmopan (Belize)": [17.2510, -88.7590],
  "Bridgetown (Barbados)": [13.1132, -59.5988],
  "Port-au-Prince (Haiti)": [18.5944, -72.3074],
  "San Salvador (El Salvador)": [13.6929, -89.2182],
  "Castries (Saint Lucia)": [14.0101, -60.9870],
  "Kingston (Giamaica)": [18.0179, -76.8099],
  "Roseau (Dominica)": [15.3092, -61.3794],
  "Ottawa": [45.4215, -75.6972],
  
  
};



var stopDuration =    1000; // Durata in millisecondi per ogni fermata (2 minuti)
var stopIndex = 0; // Indice della fermata corrente
var stops = Object.entries(capitalCities); // Array delle fermate (capitalCities)
var stopMarkers = {};
for (var stop in stops) {
  var stopLatLng = stops[stop][1];

  var stopMarkerIcon = L.icon({
    iconUrl: '../img/pointer.png', // Inserisci il percorso dell'icona PNG per il marker della fermata
    iconSize: [30, 30], // Imposta le dimensioni dell'icona
    iconAnchor: [15, 10], // Imposta l'ancoraggio dell'icona (la posizione in cui si riferisce al marker)
  });

  stopMarkers[stop] = L.marker(stopLatLng, { icon: stopMarkerIcon }).addTo(map);
  stopMarkers[stop].setOpacity(0.5); // Imposta l'opacità dei marker delle fermate
}


function moveSanta() {
  var currentStop = stops[stopIndex][1]; // Ottieni la posizione della fermata corrente
  var latLng = santaMarker.getLatLng(); // Ottieni la posizione attuale di Babbo Natale
  var currentStop = stops[stopIndex][1]; // Ottieni la posizione della fermata corrente
  var stopMarker = stopMarkers[stopIndex]; // Ottieni il marker della fermata corrente

  

  var steps = 2900; // Numero di passi per spostarsi da una città all'altra
  var stepLat = (currentStop[0] - latLng.lat) / steps;
  var stepLng = (currentStop[1] - latLng.lng) / steps;

  moveSantaStepByStep(1, steps, stepLat, stepLng, stopDuration);
}

function moveSantaStepByStep(count, steps, stepLat, stepLng, duration) {
  if (count <= steps) {
    var latLng = santaMarker.getLatLng();
    var newLat = latLng.lat + stepLat;
    var newLng = latLng.lng + stepLng;

    santaMarker.setLatLng([newLat, newLng]);
    santaPath.push([newLat, newLng]);
    santaPathLine.setLatLngs(santaPath);

    map.setView([newLat, newLng], 2); // Zoom meno ravvicinato

    setTimeout(function () {
      moveSantaStepByStep(count + 1, steps, stepLat, stepLng, duration, stopMarker);
    }, duration / steps); // Tempo di pausa tra ogni passo (in millisecondi)
  } else {
    stopIndex = (stopIndex + 1) % stops.length;  // Passa alla prossima fermata (incrementa l'indice)
    setTimeout(moveSanta, duration); // Passa alla prossima fermata dopo la durata della fermata corrente
    map.removeLayer(stopMarker);

    setTimeout(moveSanta, duration); // Passa alla prossima fermata dopo la durata della fermata corrente
  }
}
 


moveSanta(); // Avvia il viaggio di Babbo Natale tra le città

