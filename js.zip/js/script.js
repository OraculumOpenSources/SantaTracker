var map = L.map('map').setView([0, 0], 2);
var santaInitialPosition = [66.5, 25]; // Posizione iniziale di Babbo Natale

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 18,
}).addTo(map);

var santaIcon = L.icon({
  iconUrl: 'img/santa.png',
  iconSize: [100, 100],
});

var santaMarker = L.marker(santaInitialPosition, { icon: santaIcon }).addTo(map);
var santaPath = [];
santaPath.push(santaInitialPosition);
var santaPathLine = L.polyline(santaPath, { color: 'green' }).addTo(map);

var travelTime = 24 * 60 * 60 * 1000;
var distanceAroundWorld = 40000;
var speed = (distanceAroundWorld * 1000) / travelTime;

var followSanta = true; // Variabile per seguire o non seguire i movimenti di Babbo Natale

var capitalCities = {
  // Africa
  "Egitto": [30.0330, 31.2336],
  "Sudafrica": [-25.7460, 28.1871],
  "Nigeria": [9.0820, 8.6753],



  "Svezia": [59.3293, 18.0686],
  "Italia": [41.9028, 12.4964],
  "Francia": [48.8566, 2.3522],
  "Regno Unito": [51.5074, -0.1278],
  "Germania": [52.5200, 13.4050],
  "Spagna": [40.4168, -3.7038],
  "Portogallo": [38.7223, -9.1393],

 
  "Cina": [39.9042, 116.4074],
  "Giappone": [35.6895, 139.6917],
  "India": [28.6139, 77.2090],
  "Russia": [55.7558, 37.6176],
  // ... altre capitali asiatiche

  // America
  "Stati Uniti": [38.9072, -77.0369],
  "Canada": [45.4215, -75.6910],
  "Brasile": [-15.8267, -47.9218],
  "Messico": [19.4326, -99.1332],
  // ... altre capitali americane

  // Oceania
  "Australia": [-35.2820, 149.1286],
  "Nuova Zelanda": [-41.2865, 174.7762],
  // ... altre capitali oceaniane
};


for (var capital in capitalCities) {
  // Crea un'icona personalizzata per i marker delle capitali
  var capitalIcon = L.icon({
    iconUrl: 'img/pointer.png', // Inserisci l'URL dell'icona desiderata per i marker delle capitali
    iconSize: [40, 40], // Imposta le dimensioni dell'icona
    iconAnchor: [20, 40], // Imposta l'ancoraggio dell'icona (la posizione in cui si riferisce al marker)
  });

  // Aggiungi i marker personalizzati delle capitali sulla mappa con lo stile definito
  L.marker(capitalCities[capital], { icon: capitalIcon }).addTo(map).bindPopup(capital);
}

function moveSanta() {
  var latLng = santaMarker.getLatLng();
  var newLat = latLng.lat - (speed * 0.000008983 * (Math.random() * 2 - 1));
  var randomLongOffset = (Math.random() * 0.05) * (Math.random() < 0.5 ? -1 : 1);
  var newLng = latLng.lng + (speed * 0.000008983 / Math.cos(latLng.lat * Math.PI / 180)) + (randomLongOffset / Math.cos(latLng.lat * Math.PI / 180));

  santaMarker.setLatLng([newLat, newLng]);
  santaPath.push([newLat, newLng]);
  santaPathLine.setLatLngs(santaPath);

  if (followSanta) {
    map.setView([newLat, newLng], 5);
  }

  setTimeout(moveSanta, 1 + Math.random() * 300);
}

// Calcola il tempo attuale in millisecondi
var currentTime = new Date().getTime();

// Imposta il tempo in millisecondi per l'orario di partenza (24 dicembre 2023 alle 16:45 UTC)
var departureTime = new Date("December 24, 2023 9:30:00 UTC").getTime();

// Calcola il ritardo in millisecondi per far partire Babbo Natale al tempo specificato
var delay = departureTime - currentTime;

// Avvia la simulazione del movimento di Babbo Natale al tempo specificato
setTimeout(moveSanta, delay);

// Aggiungi un pulsante HTML per fissare o togliere lo zoom sulla posizione di Babbo Natale
var control = L.control();

control.onAdd = function (map) {
  var div = L.DomUtil.create('div', 'custom-control leaflet-bar');
  return div;
};

control.addTo(map);

function toggleZoom() {
  followSanta = !followSanta;
  var button = document.getElementById('toggleZoom');
  button.textContent = followSanta ? 'Stop following Santa Claus' : 'Follow Santa Claus';
}
