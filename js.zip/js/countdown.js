// Funzione per calcolare il countdown
function christmasCountdown() {
  // Data di Natale (25 dicembre)
  const christmasDate = new Date('December 25, 2024 00:00:00 UTC').getTime();

  // Calcolo del tempo attuale
  const now = new Date().getTime();

  // Calcolo della differenza tra la data di Natale e il tempo attuale
  const difference = christmasDate - now;

  // Calcolo dei giorni, ore, minuti e secondi rimanenti
  const days = Math.floor(difference / (1000 * 60 * 60 * 24));
  const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((difference % (1000 * 60)) / 1000);

  // Visualizzazione del countdown nella pagina HTML
  const countdownElement = document.getElementById('countdown');
  if (countdownElement) {
    countdownElement.innerHTML = `
      <span id="days">${days}</span> days 
      <span id="hours">${hours}</span> hours 
      <span id="minutes">${minutes}</span> minutes 
      <span id="seconds">${seconds}</span> seconds
    `;
  }
}

// Aggiornamento del countdown ogni secondo
setInterval(christmasCountdown, 1000);

// Chiamata alla funzione per avviare il countdown al caricamento della pagina
window.onload = christmasCountdown;
